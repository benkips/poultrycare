package com.mabnets.www.poultry;
import java.io.Serializable;
public class vetinaryz implements Serializable{
    public String id;
    public String username;
    public String email;
    public String phone;

}
