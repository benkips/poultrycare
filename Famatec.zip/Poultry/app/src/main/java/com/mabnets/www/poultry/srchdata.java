package com.mabnets.www.poultry;
import java.io.Serializable;
public class srchdata implements Serializable {
    public String id;
    public String disease;
    public String condition;
    public String cure;
    public String time;
}
