package com.mabnets.www.poultry;
import java.io.Serializable;
public class tipz implements Serializable {
    public String id;
    public String tip;

}
