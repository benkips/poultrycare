package com.mabnets.www.poultry;

import java.io.Serializable;
public class chatitems implements Serializable {
    public  String id;
    public String message;
    public String sender;
    public String conversation;
    public String flow;
    public String origin;
    public String time;
}
